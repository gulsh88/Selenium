/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bittertesting2018;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
/**
 *
 * @author gulsh
 */
public class BitterUnitTests {
    
    
    static boolean CreateAccountValid(WebDriver driver, String firstName, 
            String lastName, String email, String userName, String password,
    String confirm, String phone, String address, String province, String postalCode,
    String url, String desc, String location){
           try{ 
            //go to the page
            driver.get("http://192.168.1.200/qa/ryanf/SignUp.php");

            //get the webelement and then 
            WebElement txtFirstName = BitterWebElements.txtFirstName(driver);
            WebElement txtLastName = BitterWebElements.txtLastName(driver);
            WebElement txtEmail = BitterWebElements.txtEmail(driver);
            WebElement txtUsername = BitterWebElements.txtUsername(driver);
            WebElement txtPassword = BitterWebElements.txtPassword(driver);
            WebElement txtConfirm = BitterWebElements.txtConfirm(driver);
            WebElement txtPhone = BitterWebElements.txtPhone(driver);
            WebElement txtAddress = BitterWebElements.txtAddress(driver);
            WebElement cboProvince = BitterWebElements.cboProvince(driver);
            WebElement txtPostalCode = BitterWebElements.txtPostalCode(driver);
            WebElement txtUrl = BitterWebElements.txtUrl(driver);
            WebElement txtDesc = BitterWebElements.txtDesc(driver);
            WebElement txtLocation = BitterWebElements.txtLocation(driver);
            WebElement btnRegister = BitterWebElements.btnRegister(driver);

            //send information to these web elements
            txtFirstName.sendKeys(firstName);
            txtLastName.sendKeys(lastName);
            txtEmail.sendKeys(email);
            txtUsername.sendKeys(userName);
            txtPassword.sendKeys(password);
            txtConfirm.sendKeys(confirm);
            txtPhone.sendKeys(phone);
            txtAddress.sendKeys(address);
            cboProvince.sendKeys(province);
            txtPostalCode.sendKeys(postalCode);
            txtUrl.sendKeys(url);
            txtDesc.sendKeys(desc);
            txtLocation.sendKeys(location);

            btnRegister.click();//click the button

            //expected output
            String successURL2 = "http://192.168.1.200/qa/ryanf/Login.php";
            String actualURL2 = driver.getCurrentUrl();          
            if (actualURL2.contains(successURL2)) {

                return true;
            } else {

                return false;
            }
       }
       catch(Exception ex){
           return false;
       }
    }
    
    
    static boolean CreateAccountInvalid(WebDriver driver, String firstName, 
            String lastName, String email, String userName, String password,
    String confirm, String phone, String address, String province, String postalCode,
    String url, String desc, String location){
        try{
            //go to the page
            driver.get("http://192.168.1.200/qa/ryanf/SignUp.php");

            //get the webelements 
            WebElement txtFirstName = BitterWebElements.txtFirstName(driver);
            WebElement txtLastName = BitterWebElements.txtLastName(driver);
            WebElement txtEmail = BitterWebElements.txtEmail(driver);
            WebElement txtUsername = BitterWebElements.txtUsername(driver);
            WebElement txtPassword = BitterWebElements.txtPassword(driver);
            WebElement txtConfirm = BitterWebElements.txtConfirm(driver);
            WebElement txtPhone = BitterWebElements.txtPhone(driver);
            WebElement txtAddress = BitterWebElements.txtAddress(driver);
            WebElement cboProvince = BitterWebElements.cboProvince(driver);
            WebElement txtPostalCode = BitterWebElements.txtPostalCode(driver);
            WebElement txtUrl = BitterWebElements.txtUrl(driver);
            WebElement txtDesc = BitterWebElements.txtDesc(driver);
            WebElement txtLocation = BitterWebElements.txtLocation(driver);
            WebElement btnRegister = BitterWebElements.btnRegister(driver);

            //send information to these web elements
            txtFirstName.sendKeys(firstName);
            txtLastName.sendKeys(lastName);
            txtEmail.sendKeys(email);
            txtUsername.sendKeys(userName);
            txtPassword.sendKeys(password);
            txtConfirm.sendKeys(confirm);
            txtPhone.sendKeys(phone);
            txtAddress.sendKeys(address);
            cboProvince.sendKeys(province);
            txtPostalCode.sendKeys(postalCode);
            txtUrl.sendKeys(url);
            txtDesc.sendKeys(desc);
            txtLocation.sendKeys(location);
            btnRegister.click();//click the button

            //expected output
            String successURL2 = "http://192.168.1.200/qa/ryanf/Login.php";
            String actualURL2 = driver.getCurrentUrl();          
            if (actualURL2.contains(successURL2)) {

                return true;
            } else {

                return false;
            }
        }
        catch (Exception ex)
        {
            return false;
        }
    }
    
    
    static boolean UserLogin(WebDriver driver, String username, String password)
    { 
        try{
            //load the page
            driver.get("http://192.168.1.200/qa/ryanf/Login.php");

            //get the web element
            WebElement btnLoginButton = BitterWebElements.btnLoginButton(driver);
            WebElement txtUsername = BitterWebElements.txtUsername(driver);
            WebElement txtPassword = BitterWebElements.txtPassword(driver);
            WebElement btnLogin = BitterWebElements.btnLogin(driver);
            
            //send information to these webelements
            btnLoginButton.click();
            txtUsername.sendKeys(username);
            txtPassword.sendKeys(password);
            btnLogin.click();

            String strExpectedUrl = "http://192.168.1.200/qa/ryanf/Index.php";
            String strActualUrl="";

            strActualUrl=driver.getCurrentUrl();

            if(strActualUrl.contains(strExpectedUrl)){
               
                return true;
            }
            else{
                
                return false;
            }
        }catch(Exception ex){
            return false;
        }
    }
    
    static boolean CreateTweet(WebDriver driver, String text){
        try{
            BitterUnitTests.UserLogin(driver, "nick", "asdf"); //prerequiste           
            String successMessage = "Login Successful! Enjoy Trolling";
            String alertMessage = driver.switchTo().alert().getText();
            Alert a = driver.switchTo().alert();
            a.accept();
            if (alertMessage.contains(successMessage)){
                   
                    WebElement txtMyTweet = BitterWebElements.txtMyTweet(driver);
                    WebElement btnButton = BitterWebElements.btnButton(driver);

                    
                    txtMyTweet.sendKeys(text);
                    txtMyTweet.click();
                  
                    btnButton.click();
                    btnButton.click(); //must click twice
                    
                    String strExpectedUrl = "http://192.168.1.200/qa/ryanf/Index.php";
                    String strActualUrl="";
                    strActualUrl=driver.getCurrentUrl();
                    if(strActualUrl.contains(strExpectedUrl)){
                        return true;
                    }
                    else{
                        return false;
                    }
            }
            else{
                return false;
            }
        }
        catch(Exception ex){
            return false;
        }
    
    }
    
    static boolean UpdatePicture(WebDriver driver){
        try{
            BitterUnitTests.UserLogin(driver, "nick", "asdf");   //prerequisite        
            String successMessage = "Login Successful! Enjoy Trolling";
            String alertMessage = driver.switchTo().alert().getText();
            Alert a = driver.switchTo().alert();
            a.accept();
            if (alertMessage.contains(successMessage)){
                //if user logs in
                
                // Grab the main dropdown menu.
                WebElement navMenu = BitterWebElements.navMenu(driver);
                navMenu.click();

                // Grab the link by it's exact link text and click the link.
                WebElement lnkEdit = BitterWebElements.lnkEdit(driver);
                lnkEdit.click();      
                String strExpectedUrl = "http://192.168.1.200/qa/ryanf/edit_photo.php";
                String strActualUrl="";

                strActualUrl=driver.getCurrentUrl();

                if(strActualUrl.contains(strExpectedUrl)){
                    return true;
                }
                else{
                    return false;
                }
            }
        }
        catch (Exception ex){
            return false;
        }
     return false;
    }
    static void LogOutClose(WebDriver driver){         //just to log out for use in other tests
        driver.get("http://192.168.1.200/qa/ryanf/index.php");
        // Grab the main dropdown menu.
        WebElement navMenu = BitterWebElements.navMenu(driver);
        navMenu.click();
        // Grab the link by it's exact link text and click the link.
        WebElement lnkLogout = BitterWebElements.lnkLogout(driver);
        lnkLogout.click();      
        String strExpectedUrl = "http://192.168.1.200/qa/ryanf/Login.php?dbcs=logoutsuccess";
        String strActualUrl="";
        strActualUrl=driver.getCurrentUrl();
        driver.close();
    }
    static boolean Logout(WebDriver driver){
        try{
            BitterUnitTests.UserLogin(driver, "nick", "asdf");          //prereq
            String successMessage = "Login Successful! Enjoy Trolling";
            String alertMessage = driver.switchTo().alert().getText();
            Alert a = driver.switchTo().alert();
            a.accept();
            if (alertMessage.contains(successMessage)){
                // Grab the main dropdown menu.
                WebElement navMenu = BitterWebElements.navMenu(driver);
                navMenu.click();

                // Grab the link by it's exact link text and click the link.
                WebElement lnkLogout = BitterWebElements.lnkLogout(driver);
                lnkLogout.click();      
                String strExpectedUrl = "http://192.168.1.200/qa/ryanf/Login.php?dbcs=logoutsuccess";
                String strActualUrl="";
                strActualUrl=driver.getCurrentUrl();
                if(strActualUrl.contains(strExpectedUrl)){
                    return true;
                }
                else{
                    return false;
                }
            }
        }
        catch (Exception ex){
            return false;
        }
     return false;
    }
    
    static boolean Follow(WebDriver driver){
        try{
            BitterUnitTests.UserLogin(driver, "nick", "asdf");       //prereq    
            String successMessage = "Login Successful! Enjoy Trolling";
            String alertMessage = driver.switchTo().alert().getText();
            Alert a = driver.switchTo().alert();
            a.accept();
            if (alertMessage.contains(successMessage)){
                
                WebElement lnkFollow = BitterWebElements.lnkFollow(driver);
                lnkFollow.click();  
                
                String success = "Following User!";
                String alert = driver.switchTo().alert().getText();
                Alert b = driver.switchTo().alert();
                b.accept();
                
                if (alertMessage.contains(success)){
                    
                    String strExpectedUrl = "http://192.168.1.200/qa/ryanf/Index.php?dbcs=folsc";
                    String strActualUrl="";

                    strActualUrl=driver.getCurrentUrl();

                    if(strActualUrl.contains(strExpectedUrl)){
                        return true;
                    }
                    else{
                        return false;
                    }
                }
            }
        }
        catch (Exception ex){
            return false;
        }
     return false;
    }
    
    static boolean Email(WebDriver driver){
        try{
            BitterUnitTests.UserLogin(driver, "nick", "asdf");//prerequsite           
            String successMessage = "Login Successful! Enjoy Trolling";
            String alertMessage = driver.switchTo().alert().getText();
            Alert a = driver.switchTo().alert();
            a.accept();
            if (alertMessage.contains(successMessage)){
                // Grab the main dropdown menu.
                WebElement navMenu = BitterWebElements.navMenu(driver);
                navMenu.click();
                WebElement lnkContact = BitterWebElements.lnkContact(driver);
                lnkContact.click();      
                String strExpectedUrl = "http://192.168.1.200/qa/ryanf/ContactUs.php";
                String strActualUrl="";

                strActualUrl=driver.getCurrentUrl();

                if(strActualUrl.contains(strExpectedUrl)){
                    WebElement lnkPreEmail = BitterWebElements.preEmail(driver);
                    lnkPreEmail.click();  
                    WebElement lnkEmail=BitterWebElements.lnkEmail(driver);
                    lnkEmail.click();
                    
                    return true;
                }
                else{
                    return false;
                }
            }
        }
        catch (Exception ex){
            return false;
        }
     return false;
    }
    
    static boolean ViewUser(WebDriver driver){
        try{
            BitterUnitTests.UserLogin(driver, "nick", "asdf"); //prereq
           
            String successMessage = "Login Successful! Enjoy Trolling";
            String alertMessage = driver.switchTo().alert().getText();
            Alert a = driver.switchTo().alert();
            a.accept();
            if (alertMessage.contains(successMessage)){
                
                WebElement lnkProfile = BitterWebElements.lnkMyPage(driver);
                lnkProfile.click();  
                    
                String strExpectedUrl = "http://192.168.1.200/qa/ryanf/userpage.php?UserID='127'";
                String strActualUrl="";

                strActualUrl=driver.getCurrentUrl();

                if(strActualUrl.contains(strExpectedUrl)){
                    return true;
                }
                else{
                    return false;
                }
            }
        }
        catch (Exception ex){
            return false;
        }
     return false;
    }
    
    
}
