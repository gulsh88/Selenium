/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bittertesting2018;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;




/**
 *
 * @author gulsh
 */
public class BitterTesting2018 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        WebDriver driver = BitterWebElements.initWebDriver();

        boolean BIT001; //flag for the test
        BIT001 = BitterUnitTests.CreateAccountValid(driver, "Gulshan", "Gill", "ggill123@gmail.com", "tester", "test", "test", "123 456 7899","123 Main St", "N", "E3A1A3", "www.nbcc.ca", "live laugh love", "fredericton");
//        BitterUnitTests.LogOutClose(driver); //log out and close the driver
        System.out.println("BIT001 Create an account: " + BIT001);


        boolean BIT002;
        BIT002 = BitterUnitTests.CreateAccountInvalid(driver, "Gulshan", "Gill", "ggill123@gmail.com", "tester", "test", "test", "123 456 7899","123 Main St", "N", "333 3333", "www.nbcc.ca", "live laugh love", "fredericton");
//        BitterUnitTests.LogOutClose(driver);
        System.out.println("BIT002 Create an account with invalid postcode: " + BIT002);


        boolean BIT003;
        BIT003 = BitterUnitTests.UserLogin(driver, "nick", "asdf");
//        BitterUnitTests.LogOutClose(driver);
        System.out.println("BIT003 LOGIN: " + BIT003);


        boolean BIT004;
        BIT004 = BitterUnitTests.UserLogin(driver, "Nouser", "test");
        //BitterUnitTests.LogOutClose(driver);
        System.out.println("BIT004 LOGIN with invalid user: " + BIT004);


        boolean BIT005;
        BIT005 = BitterUnitTests.CreateTweet(driver, "this is test 5");
//        BitterUnitTests.LogOutClose(driver);
        System.out.println("BIT005 TWEET: " + BIT005);


        boolean BIT006;
        BIT006 = BitterUnitTests.CreateTweet(driver, "this is test 6!!!");
      //  BitterUnitTests.LogOutClose(driver);
        System.out.println("BIT006 Tweet with special characters: " + BIT006);


        boolean BIT007 = BitterUnitTests.CreateAccountInvalid(driver, "Gulshan", "Gill","ggill123gmail.com", "tester", "test", "test", "123 456 7899","123 Main St", "N", "E3A1A3", "www.nbcc.ca", "live laugh love", "fredericton");
        //BitterUnitTests.LogOutClose(driver);
        System.out.println("BIT007 Create an account with invalid email: " + BIT007);


        boolean BIT008 = BitterUnitTests.CreateAccountInvalid(driver, "Gulshan", "Gill","ggill12@gmail.com", "tester", "test", "test", "123 456 6789 1234567","123 Main St", "N", "E3A1A3", "www.nbcc.ca", "live laugh love", "fredericton");
        //BitterUnitTests.LogOutClose(driver);
        System.out.println("BIT008 Create an account with invalid phone: " + BIT008);


        boolean BIT009 = BitterUnitTests.CreateAccountInvalid(driver, "Gulshan", "Gill","ggill12@gmail.com", "tester", "test", "test", "123 456 6789","123 Main St", "N", "E3A1A3", "www.nbcc.ca", "live laugh love", "fredericton");
       // BitterUnitTests.LogOutClose(driver);
        System.out.println("BIT009 Create an account with an already used username: " + BIT009);     


        boolean BIT010;
        BIT010 = BitterUnitTests.UserLogin(driver, "nick", "test");
//        BitterUnitTests.LogOutClose(driver);
        System.out.println("BIT010 LOGIN with bad password: " + BIT010);


        boolean BIT011;
        BIT011=BitterUnitTests.UpdatePicture(driver);
    //    BitterUnitTests.LogOutClose(driver);
        System.out.println("BIT011 update Pic: " + BIT011);


        boolean BIT012;
        BIT012=BitterUnitTests.Logout(driver);
      //  BitterUnitTests.LogOutClose(driver);
        System.out.println("BIT012 logout test: " + BIT012);


        boolean BIT013;
        BIT013=BitterUnitTests.Follow(driver);
     //   BitterUnitTests.LogOutClose(driver);
        System.out.println("BIT013 FOLLOW test: " + BIT013 );


        boolean BIT014;
        BIT014=BitterUnitTests.Email(driver);
     //   BitterUnitTests.LogOutClose(driver);
        System.out.println("BIT014 Email test: " + BIT014);

        boolean BIT015;
        BIT015=BitterUnitTests.ViewUser(driver);
     //   BitterUnitTests.LogOutClose(driver);
        System.out.println("BIT015 View User test: " + BIT015);          
        
        boolean BIT016;
        String text = "i hope this 'breaks' his code";
        BIT016 = BitterUnitTests.CreateTweet(driver, text);
        System.out.println("BIT016: Tweet with an apostrophe : " + BIT016);
        
        boolean BIT017;
        BIT017 = BitterUnitTests.CreateTweet(driver, " ");
        System.out.println("BIT017 Tweet nothing, aka a blank string: " + BIT017);
        
        boolean BIT018;
        BIT018 = BitterUnitTests.CreateTweet(driver, "");
        System.out.println("BIT017 Tweet null: " + BIT018);
    }
    
}
