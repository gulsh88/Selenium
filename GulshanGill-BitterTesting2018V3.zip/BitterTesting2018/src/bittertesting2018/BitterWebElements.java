/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bittertesting2018;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 *
 * @author gulsh
 */
public class BitterWebElements {
    //initialize one driver and pass that along to each test
    static WebDriver initWebDriver(){ 
        System.setProperty("webdriver.chrome.driver",
                "c:/Users/gulsh/Desktop/chromedriver_win32/chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        return driver; 
    }
    
    //get all the web elements from the website
    static WebElement txtFirstName(WebDriver driver){
        WebElement txtFirstName = driver.findElement(By.id("firstname"));
        return txtFirstName;
    }
    static WebElement txtLastName(WebDriver driver){
        WebElement txtLastName = driver.findElement(By.id("lastname"));
        return txtLastName;
    }
    
    static WebElement txtEmail(WebDriver driver){
        WebElement txtEmail = driver.findElement(By.id("email"));
        return txtEmail;
    }
    
    static WebElement txtUsername(WebDriver driver){
        WebElement txtUsername = driver.findElement(By.id("username"));
        return txtUsername;
    }
    
    static WebElement txtPassword(WebDriver driver){
        WebElement txtPassword = driver.findElement(By.id("password"));
        return txtPassword;
    }
    
    static WebElement txtConfirm(WebDriver driver){
        WebElement txtConfirm = driver.findElement(By.id("confirm"));
        return txtConfirm;
    }
    
    static WebElement txtPhone(WebDriver driver){
         WebElement txtPhone = driver.findElement(By.id("phone"));
         return txtPhone;
    }
    static WebElement txtAddress(WebDriver driver){
        WebElement txtAddress = driver.findElement(By.id("address"));
        return txtAddress;
    }
    
    static WebElement cboProvince(WebDriver driver){
         WebElement cboProvince = driver.findElement(By.id("province"));
         return cboProvince;
    }
    
    static WebElement txtPostalCode(WebDriver driver){
        WebElement txtPostalCode = driver.findElement(By.id("postalCode"));
        return txtPostalCode;
    }
    
    static WebElement txtUrl(WebDriver driver){
        WebElement txtUrl = driver.findElement(By.id("url"));
        return txtUrl;
    }
    
    static WebElement txtDesc(WebDriver driver){
        WebElement txtDesc = driver.findElement(By.id("desc"));
        return txtDesc;
    }
    
    static WebElement txtLocation(WebDriver driver){
        WebElement txtLocation = driver.findElement(By.id("location"));
        return txtLocation;
    }
    
    static WebElement btnRegister(WebDriver driver){
        WebElement btnRegister = driver.findElement(By.id("button"));
        return btnRegister;
    }
    
    static WebElement btnLoginButton(WebDriver driver){
        WebElement btnLoginButton=driver.findElement(By.id("LoginBtn"));
        return btnLoginButton; //INITIAL BUTTON
    }
    static WebElement btnLogin(WebDriver driver){
        WebElement btnLogin =driver.findElement(By.id("button"));
        return btnLogin; //CONFIRM LOGIN
    }
    
    static WebElement txtMyTweet(WebDriver driver){
        WebElement txtMyTweet = driver.findElement(By.id("myTweet"));
        return txtMyTweet;
    }
    
    static WebElement btnButton(WebDriver driver){
        WebElement btnButton = driver.findElement(By.id("button"));
        return btnButton;
    }
    static WebElement navMenu(WebDriver driver){
        WebElement navMenu=driver.findElement(By.id("ProfilePic"));
        return navMenu;
    }
    static WebElement lnkEdit(WebDriver driver){
        WebElement lnkEdit= driver.findElement(By.linkText("Edit Profile Picture"));
        return lnkEdit;
    }
    static WebElement lnkLogout(WebDriver driver){
        WebElement lnkLogout = driver.findElement(By.linkText("Logout"));
        return lnkLogout;
    }
    static WebElement lnkFollow(WebDriver driver){
        return driver.findElement(By.id("followbtn"));
    }
    
    static WebElement lnkContact(WebDriver driver){
        return driver.findElement(By.linkText("Contact Us"));
    }
    
    static WebElement preEmail(WebDriver driver){
        return driver.findElement(By.linkText("Email"));
    }
    
    static WebElement lnkEmail(WebDriver driver){
        return driver.findElement(By.linkText("TechSupport@Bitters.com"));
    }
    
    static WebElement lnkMyPage(WebDriver driver){
        return driver.findElement(By.id("ProfilePic"));
    }    
}
